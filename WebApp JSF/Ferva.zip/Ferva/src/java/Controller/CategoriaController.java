/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import model.CategoriaTO;
import service.ServicioCategoria;

/**
 *
 * @author Mauricio
 */
@ManagedBean(name = "CategoriaController")
@ViewScoped

public class CategoriaController implements Serializable {

    private String nombre;
    private String descripcion;
    private boolean estado;
    private ServicioCategoria servicioCategoria = new ServicioCategoria();
    private CategoriaTO categoriaTO = null;
    List<CategoriaTO> listaCategoriaTO = new ArrayList<CategoriaTO>();
    private CategoriaTO selectedCategoria = null;

    public CategoriaController() {
    }

   
        public void openNew() {
        this.selectedCategoria = new CategoriaTO();
    }
            public void saveCategoria() {
        System.out.println("Lo valores digitados por el usuario han sido: " + this.selectedCategoria);
        if (this.selectedCategoria.getIdcategoria()== 0) {
            this.servicioCategoria.insertar(this.selectedCategoria);
        } else {
            this.servicioCategoria.actualizar(this.selectedCategoria);
        }
        this.cargar();
    }

    public void deleteCategoria() {
        this.servicioCategoria.eliminar(this.selectedCategoria);
        this.cargar();
    }
    public void redireccionar(String ruta) {
        HttpServletRequest request;
        try {
            request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            FacesContext.getCurrentInstance().getExternalContext().redirect(request.getContextPath() + ruta);
        } catch (Exception e) {

        }
    }

  

    public void salir() {

        try {
            FacesContext.getCurrentInstance().getExternalContext()
                    .invalidateSession();

            HttpServletRequest request = (HttpServletRequest) FacesContext
                    .getCurrentInstance().getExternalContext().getRequest();
            FacesContext
                    .getCurrentInstance()
                    .getExternalContext()
                    .redirect(
                            request.getContextPath()
                            + "/faces/index.xhtml?faces-redirect=false");
        } catch (Exception e) {
        }
    }

public void redirectCrud(){
    this.redireccionar("/faces/AdministradorCrudUsers.xhtml");
}
    @PostConstruct
    public void cargar() {
        this.listaCategoriaTO = servicioCategoria.listarCategoriasDB();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public ServicioCategoria getServicioCategoria() {
        return servicioCategoria;
    }

    public void setServicioCategoria(ServicioCategoria servicioCategoria) {
        this.servicioCategoria = servicioCategoria;
    }

    public List<CategoriaTO> getListaCategoriaTO() {
        return listaCategoriaTO;
    }

    public void setListaCategoriaTO(List<CategoriaTO> listaCategoriaTO) {
        this.listaCategoriaTO = listaCategoriaTO;
    }

    public CategoriaTO getSelectedCategoria() {
        return selectedCategoria;
    }

    public void setSelectedCategoria(CategoriaTO selectedCategoria) {
        this.selectedCategoria = selectedCategoria;
    }


}
