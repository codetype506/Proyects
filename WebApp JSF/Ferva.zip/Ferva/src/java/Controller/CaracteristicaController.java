/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import model.CaracteristicaTO;
import service.ServicioCaracteristica;
import service.ServicioCategoria;

/**
 *
 * @author Mauricio
 */
@ManagedBean(name = "CaracteristicaController")
@ViewScoped
public class CaracteristicaController implements Serializable {

    private String nombre;
    private String descripcion;
    private double precio;
    private String orden;
    private boolean estado;
    private ServicioCaracteristica servicioCaracteristica = new ServicioCaracteristica();
    private CaracteristicaTO caracteristicaTO = null;
    List<CaracteristicaTO> listaCaracteristicaTO = new ArrayList<CaracteristicaTO>();
    private CaracteristicaTO selectedCaracteristica = null;

    public CaracteristicaController() {
    }

    public void openNew() {
        this.selectedCaracteristica = new CaracteristicaTO();
    }

    public void saveCaracteristica() {
        System.out.println("Lo valores digitados por el usuario han sido: " + this.selectedCaracteristica);
        if (this.selectedCaracteristica.getIdcaractaristica() == 0) {
            this.servicioCaracteristica.insertar(this.selectedCaracteristica);
        } else {
            this.servicioCaracteristica.actualizar(this.selectedCaracteristica);
        }
        this.cargar();
    }

    public void deleteCaracteristica() {
        this.servicioCaracteristica.eliminar(this.selectedCaracteristica);
        this.cargar();
    }

    public void redireccionar(String ruta) {
        HttpServletRequest request;
        try {
            request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            FacesContext.getCurrentInstance().getExternalContext().redirect(request.getContextPath() + ruta);
        } catch (Exception e) {

        }
    }

    public void salir() {

        try {
            FacesContext.getCurrentInstance().getExternalContext()
                    .invalidateSession();

            HttpServletRequest request = (HttpServletRequest) FacesContext
                    .getCurrentInstance().getExternalContext().getRequest();
            FacesContext
                    .getCurrentInstance()
                    .getExternalContext()
                    .redirect(
                            request.getContextPath()
                            + "/faces/index.xhtml?faces-redirect=false");
        } catch (Exception e) {
        }
    }
public void redirectCrud(){
    this.redireccionar("/faces/AdministradorCrudCaracteristicas.xhtml");
}
    @PostConstruct
    public void cargar() {
        this.listaCaracteristicaTO = servicioCaracteristica.listarCaracteristicasDB();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public ServicioCaracteristica getServicioCaracteristica() {
        return servicioCaracteristica;
    }

    public void setServicioCaracteristica(ServicioCaracteristica servicioCaracteristica) {
        this.servicioCaracteristica = servicioCaracteristica;
    }

    public CaracteristicaTO getCaracteristicaTO() {
        return caracteristicaTO;
    }

    public void setCaracteristicaTO(CaracteristicaTO caracteristicaTO) {
        this.caracteristicaTO = caracteristicaTO;
    }

    public List<CaracteristicaTO> getListaCaracteristicaTO() {
        return listaCaracteristicaTO;
    }

    public void setListaCaracteristicaTO(List<CaracteristicaTO> listaCaracteristicaTO) {
        this.listaCaracteristicaTO = listaCaracteristicaTO;
    }

    public CaracteristicaTO getSelectedCaracteristica() {
        return selectedCaracteristica;
    }

    public void setSelectedCaracteristica(CaracteristicaTO selectedCaracteristica) {
        this.selectedCaracteristica = selectedCaracteristica;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getOrden() {
        return orden;
    }

    public void setOrden(String orden) {
        this.orden = orden;
    }

}
