/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import model.CaracteristicaTO;
import service.ServicioCaracteristica;
import model.UsuarioTO;
import service.ServicioUsuario;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import model.CategoriaTO;
import service.ServicioCategoria;

/**
 *
 * @author User
 */
@ManagedBean(name = "loginController")
@ViewScoped

//login
public class LoginController implements Serializable {

    private String correo;
    private String clave;
    private boolean userType;
    private ServicioUsuario servicioUsuario = new ServicioUsuario();
    private UsuarioTO usuarioTO = null;
    List<UsuarioTO> listaUsuarios = new ArrayList<UsuarioTO>();
    private UsuarioTO selectedUsuario = null;
    private boolean value1;
    private ServicioCategoria servicioCategoria = new ServicioCategoria();
    List<CategoriaTO> listaCategoriaTO = new ArrayList<CategoriaTO>();
    private ServicioCaracteristica servicioCaracteristica = new ServicioCaracteristica();
    List<CaracteristicaTO> listaCaracteristicaTO = new ArrayList<CaracteristicaTO>();

//metodo login
    public LoginController() {
    }

//metodo @PostConstruc
    @PostConstruct
    public void cargar() {
        this.listaCategoriaTO = servicioCategoria.listarCategoriasDB();
        this.listaUsuarios = servicioUsuario.listarUsuariosDB();
    }

    //==============================================================================
    public void ingresar() {
        System.out.println("El valor digitado por el usuario (user) es: " + this.getCorreo());
        System.out.println("El valor digitado por el usuario (password) es: " + this.getClave());

        if (this.getCorreo() == null || "".equals(this.getCorreo())) {
            FacesContext.getCurrentInstance().addMessage("sticky-key", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Campos inválidos", "El correo electrónico no es correcto"));
        } else {
            usuarioTO = servicioUsuario.existeUsuario(this.getCorreo(), this.getClave(), this.getUserType());

            if (usuarioTO != null) {
                // usuarioTO = servicioUsuario.devuelveUsuario(this.getCorreo(), this.getClave()); usuarioTO = servicioUsuario.devuelveUsuario(this.getClave(), this.getCorreo());
                //Obtiene la lista de usuarios registrados en la base de datos
                this.listaCategoriaTO = servicioCategoria.listarCategoriasDB();
                this.listaUsuarios = servicioUsuario.listarUsuariosDB();
                this.listaCaracteristicaTO = servicioCaracteristica.listarCaracteristicasDB();
                this.redireccionar("/faces/administrador.xhtml");

            } else {
                this.listaUsuarios = servicioUsuario.listarUsuariosDB();
                this.listaCategoriaTO = servicioCategoria.listarCategoriasDB();
                this.listaCaracteristicaTO = servicioCaracteristica.listarCaracteristicasDB();
                this.redireccionar("/faces/bienvenidaUser.xhtml");
                FacesContext.getCurrentInstance().addMessage("sticky-key", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Autenticación", "Los credenciales no son válidos."));
            }

        }
    }

    //==============================================================================
    public void openNew() {
        this.selectedUsuario = new UsuarioTO();
    }

    //==============================================================================
    public void saveUser() {
        System.out.println("Lo valores digitados por el usuario han sido: " + this.selectedUsuario);
        if (this.selectedUsuario.getUser_id() == 0) {
            this.servicioUsuario.insertar(this.selectedUsuario);
        } else {
            this.servicioUsuario.actualizar(this.selectedUsuario);
        }
        this.cargar();
    }

    public void deleteUser() {
        this.servicioUsuario.eliminar(this.selectedUsuario);
        this.cargar();
    }

    /*public void insertUser() {
        selectedUsuario.setPassword(this.getClave());
        selectedUsuario.setEmail(this.getCorreo());
        this.servicioUsuario.insertar(selectedUsuario);
    }*/
    //==============================================================================
    //===========================================================================================
    public void redireccionar(String ruta) {
        HttpServletRequest request;
        try {
            request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            FacesContext.getCurrentInstance().getExternalContext().redirect(request.getContextPath() + ruta);
        } catch (Exception e) {

        }
    }

    public void salir() {

        try {
            FacesContext.getCurrentInstance().getExternalContext()
                    .invalidateSession();

            HttpServletRequest request = (HttpServletRequest) FacesContext
                    .getCurrentInstance().getExternalContext().getRequest();
            FacesContext
                    .getCurrentInstance()
                    .getExternalContext()
                    .redirect(
                            request.getContextPath()
                            + "/faces/index.xhtml?faces-redirect=true");
        } catch (Exception e) {
        }
    }

    public boolean isValue1() {
        return value1;
    }

    public void setValue1(boolean value1) {
        this.value1 = value1;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public UsuarioTO getUsuarioTO() {
        return usuarioTO;
    }

    public void setUsuarioTO(UsuarioTO usuarioTO) {
        this.usuarioTO = usuarioTO;
    }

    public List<UsuarioTO> getListaUsuarios() {
        return listaUsuarios;
    }

    public UsuarioTO getSelectedUsuario() {
        return selectedUsuario;
    }

    public void setSelectedUsuario(UsuarioTO selectedUsuario) {
        this.selectedUsuario = selectedUsuario;
    }

    public boolean getUserType() {
        return userType;
    }

    public void setUserType(boolean userType) {
        this.userType = userType;
    }

}
