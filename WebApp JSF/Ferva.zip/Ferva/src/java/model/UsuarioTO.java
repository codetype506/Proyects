/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author User
 */
public class UsuarioTO implements Serializable {

    private int user_id;
    private String email;
    private String password;
    private String first_name;
    private boolean userType2;

    public UsuarioTO() {
    }

    public UsuarioTO(String email, String password, String first_name) {
        this.email = email;
        this.password = password;
        this.first_name = first_name;

    }
     public UsuarioTO(int user_id, String first_name, String password, String email) {
        this.user_id = user_id;
        this.first_name = first_name;
        this.password = password;
        this.email = email;
          
    }

    public UsuarioTO(int user_id, String first_name, String password, String email, boolean userType2) {
        this.user_id = user_id;
        this.first_name = first_name;
        this.password = password;
        this.email = email;
        this.userType2 = userType2;
    }

    public UsuarioTO(int idCat, String name, String description, boolean state) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public boolean isUserType2() {
        return userType2;
    }

    public void setUserType2(boolean userType2) {
        this.userType2 = userType2;
    }



}
