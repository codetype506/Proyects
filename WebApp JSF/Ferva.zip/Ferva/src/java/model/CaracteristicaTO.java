/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author Mauricio
 */
public class CaracteristicaTO implements Serializable {

    private int idcaractaristica;
    private String nombre;
    private String descripcion;
    private int precio;
    private String orden;
    private boolean estado;

    public CaracteristicaTO() {
    }

    public CaracteristicaTO(int idcaractaristica, String nombre, String descripcion, int precio, String orden, boolean estado) {
        this.idcaractaristica = idcaractaristica;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.orden = orden;
        this.estado = estado;
    }

    public CaracteristicaTO(int idcaractaristica, String nombre, String descripcion, boolean estado) {
        this.idcaractaristica = idcaractaristica;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.estado = estado;
    }

    public int getIdcaractaristica() {
        return idcaractaristica;
    }

    public void setIdcaractaristica(int idcaractaristica) {
        this.idcaractaristica = idcaractaristica;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getOrden() {
        return orden;
    }

    public void setOrden(String orden) {
        this.orden = orden;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }



}