/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;
import javax.swing.JOptionPane;
import model.CategoriaTO;
import model.UsuarioTO;
import static org.primefaces.component.keyboard.KeyboardBase.PropertyKeys.password;

/**
 *
 * @author User
 */
public class ServicioUsuario extends Servicio {

    public UsuarioTO existeUsuario(String correo, String clave, boolean userType) {
        Statement stmt = null;
        ResultSet rs = null;
        UsuarioTO usuarioTORetorno = null;

        try {
            conectar();

            stmt = conexion.createStatement();
            String sql = "SELECT user_id,email, first_name, password , userType  FROM user WHERE email = '" + correo + "' AND password = '" + clave + "' AND userType = '" + "0" + "' ";
            rs = stmt.executeQuery(sql);

            if (rs.next()) {
                int user_id = rs.getInt("user_id");
                String email = rs.getString("email");
                String first_name = rs.getString("first_name");
                String password = rs.getString("password");
                boolean userType2 = rs.getBoolean("userType");

                usuarioTORetorno = new UsuarioTO(user_id, email, first_name, password, userType2);

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //Paso 5
            cerrarResultSet(rs);
            cerrarStatement(stmt);
            desconectar();
        }
        return usuarioTORetorno;
    }

    /*
     public UsuarioTO AdminOrUser(boolean Usertype) {
        Statement stmt = null;
        ResultSet rs = null;
        UsuarioTO usuarioTORetorno = null;

        try {
            conectar();

            stmt = conexion.createStatement();
            String sql = "SELECT * FROM user WHERE Usertype = '" + Usertype + "'";
            rs = stmt.executeQuery(sql);
         
            if (rs.getBoolean(sql)) {
           boolean b = Usertype ;

                usuarioTORetorno = new UsuarioTO(Usertype);

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //Paso 5
            cerrarResultSet(rs);
            cerrarStatement(stmt);
            desconectar();
        }
        return usuarioTORetorno;
     }
     
    //===========================================================
    
    //Retorna UNA persona
/*
    public UsuarioTO RetornaUsuario(int user_id) {

        Statement stmt = null;
        ResultSet rs = null;
        UsuarioTO usuarioTORetorno = null;

        try {
            conectar();
            //Paso 3
            stmt = conexion.createStatement();
            String sql = "SELECT * FROM user WHERE user_id = " + "first_name";
            //Paso 4
            rs = stmt.executeQuery(sql);

            if (rs.next()) {
               
                String first_name = rs.getString("first_name");
                String password = rs.getString("password");

                UsuarioTO usuarioTO = new UsuarioTO(user_id, first_name, password);
                usuarioTORetorno = new UsuarioTO(user_id, first_name, password);

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //Paso 5
            cerrarResultSet(rs);
            cerrarStatement(stmt);
            desconectar();
        }
        return usuarioTORetorno;
    }
     */
    //==================================================================================
    public UsuarioTO demeUsuario(String correo, String clave, String userType) {
        UsuarioTO usuarioTO = null;
        if ("admin@test.com".equalsIgnoreCase(correo) && "test".equalsIgnoreCase(clave)) {
            return new UsuarioTO("admin@test.com", "test", "Juan");
        }
        return usuarioTO;
    }

    public ServicioUsuario() {
    }

    //======================================================================================
    //LISTAR USUARIOS DE LA DB
    //=======================================================================================
    public List<UsuarioTO> listarUsuariosDB() {

        Statement stmt = null;
        ResultSet rs = null;
        List<UsuarioTO> listaRetorno = new ArrayList<>();

        try {
            conectar();
            stmt = conexion.createStatement();
            String sql = "SELECT user_id, first_name, password, email FROM user";
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int user_id = rs.getInt("user_id");
                String first_name = rs.getString("first_name");
                String password = rs.getString("password");
                String email = rs.getString("email");
                UsuarioTO usuarioTO = new UsuarioTO(user_id, first_name, password, email);
                listaRetorno.add(usuarioTO);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarResultSet(rs);
            cerrarStatement(stmt);
            desconectar();
        }
        return listaRetorno;

    }
    //===============================================================

    public UsuarioTO devuelveUsuario(String correo, String clave, String userType) {

        UsuarioTO usuarioTO = null;
        if ("admin@test.com".equalsIgnoreCase(correo) && "test".equalsIgnoreCase(clave)) {
            return new UsuarioTO("admin@test.com", "test", "Administrador de Sistema");
        }
        return usuarioTO;
    }
    //===============================================================

    public void insertar(UsuarioTO usuarioTO) {

        //ResultSet rs = null;
        PreparedStatement pstmt = null;

        try {
            conectar();

            pstmt = conexion.prepareStatement("INSERT INTO Ferva.user (email, password,first_name, userType) VALUES (?,?,?,?)");
            //Class.forName("com.mysql.jdbc.Driver");
            // Connection connection = pstmt.getConnection();
            pstmt.setString(1, usuarioTO.getEmail());
            pstmt.setString(2, usuarioTO.getPassword());
            pstmt.setString(3, usuarioTO.getFirst_name());
            pstmt.setBoolean(4, false);
            pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPreparedStatement(pstmt);
            } catch (SQLException e) {

            }

            desconectar();
        }

    }

    public void insertaradmin(UsuarioTO usuarioTO) {

        //ResultSet rs = null;
        PreparedStatement pstmt = null;

        try {
            conectar();

            pstmt = conexion.prepareStatement("INSERT INTO Ferva.user (email, password,first_name) VALUES (?,?,?,?)");
            //Class.forName("com.mysql.jdbc.Driver");
            // Connection connection = pstmt.getConnection();
            pstmt.setString(1, usuarioTO.getEmail());
            pstmt.setString(2, usuarioTO.getPassword());
            pstmt.setString(3, usuarioTO.getFirst_name());
            pstmt.setBoolean(4, true);

            pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPreparedStatement(pstmt);
            } catch (SQLException e) {

            }

            desconectar();
        }

    }

    /* public void insertar(UsuarioTO usuarioTO) {
        System.out.println("Este es el usuario a insertar en la base de datos desde el ServicioUsuario: "+usuarioTO);
  
    public void ModificarActive() {

     PreparedStatement pstmt = null;

        try {
            conectar();

            pstmt = conexion.prepareStatement("UPDATE user SET active= '" + active + "'");



            pstmt.executeUpdate(pstmt);
            
            JOptionPane.showInputDialog(null, "Datos actualizados");
            
     } catch (Exception e) {
   
            JOptionPane.showInputDialog(null, "No se han podido actualizar los datos" + ex);
        }
    }
}  }*/
    public void actualizar(UsuarioTO usuarioTO) {
        PreparedStatement pstmt = null;

        try {
            conectar();

            pstmt = conexion.prepareStatement("UPDATE Ferva.user SET email = ? , password = ?, first_name = ? WHERE user_id = '" + usuarioTO.getUser_id() + "'");
            // Connection connection = pstmt.getConnection();
            pstmt.setString(1, usuarioTO.getEmail());
            pstmt.setString(2, usuarioTO.getPassword());
            pstmt.setString(3, usuarioTO.getFirst_name());

            pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPreparedStatement(pstmt);
            } catch (SQLException e) {

            }

            desconectar();
        }
        System.out.println("Este es el usuario a actualizar en la base de datos desde el ServicioUsuario: " + usuarioTO);
    }

    public void actualizaradmin(UsuarioTO usuarioTO) {
        PreparedStatement pstmt = null;

        try {
            conectar();

            pstmt = conexion.prepareStatement("UPDATE Ferva.user SET email = ? , password = ?, first_name = ? , userType=0 WHERE user_id = '" + usuarioTO.getUser_id() + "'");
            // Connection connection = pstmt.getConnection();
            pstmt.setString(1, usuarioTO.getEmail());
            pstmt.setString(2, usuarioTO.getPassword());
            pstmt.setString(3, usuarioTO.getFirst_name());

            pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPreparedStatement(pstmt);
            } catch (SQLException e) {

            }

            desconectar();
        }
        System.out.println("Este es el usuario a actualizar en la base de datos desde el ServicioUsuario: " + usuarioTO);
    }

    public void eliminar(UsuarioTO usuarioTO) {
        PreparedStatement pstmt = null;

        try {
            conectar();

            pstmt = conexion.prepareStatement("DELETE FROM Ferva.user  WHERE user_id = '" + usuarioTO.getUser_id() + "'");

            pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPreparedStatement(pstmt);
            } catch (SQLException e) {

            }

            desconectar();
        }

        System.out.println("Este es el usuario a eliminar en la base de datos desde el ServicioUsuario: " + usuarioTO);
    }
    
}

//========================

