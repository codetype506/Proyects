/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.CaracteristicaTO;

/**
 *
 * @author Mauricio
 */
public class ServicioCaracteristica extends Servicio{
    public CaracteristicaTO existeCaracteristica(int idcaracteristica,String nombre, String descripcion, boolean estado) {
        Statement stmt = null;
        ResultSet rs = null;
        CaracteristicaTO CaracteristicaTORetorno= null;

        try {
            conectar();

            stmt = conexion.createStatement();
            String sql = "SELECT idCategoria ,nombre, descripcion, estado  FROM caracteristica WHERE idcaracteristica = '" + idcaracteristica + "' AND nombre = '" + nombre + "' AND estado = '" + "1" + "' ";
            rs = stmt.executeQuery(sql);

            if (rs.next()) {
                int idCar = rs.getInt("idCaracteristica");
                String name = rs.getString("nombre");
                String description = rs.getString("descripcion");
                boolean state = rs.getBoolean("estado");

                CaracteristicaTORetorno = new CaracteristicaTO(idCar, name, description, state );

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //Paso 5
            cerrarResultSet(rs);
            cerrarStatement(stmt);
            desconectar();
        }
        return CaracteristicaTORetorno;
    }


    //======================================================================================
    //LISTAR caracteristicas DE LA DB
    //=======================================================================================
    public List<CaracteristicaTO> listarCaracteristicasDB() {

        Statement stmt = null;
        ResultSet rs = null;
        List<CaracteristicaTO> listaRetorno = new ArrayList<>();

        try {
            conectar();
            stmt = conexion.createStatement();
            String sql = "SELECT idcaracteristica, nombre, descripcion, estado FROM caracteristica";
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int idcaracteristicas = rs.getInt("idcaracteristica");
                String nombre = rs.getString("nombre");
                String descripcion = rs.getString("descripcion");
                boolean estado = rs.getBoolean("estado");
                CaracteristicaTO caracteristicaTO = new CaracteristicaTO(idcaracteristicas, nombre, descripcion, estado);
                listaRetorno.add(caracteristicaTO);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarResultSet(rs);
            cerrarStatement(stmt);
            desconectar();
        }
        return listaRetorno;

    }
    //===============================================================
public void insertar(CaracteristicaTO caracteristicaTO) {

        //ResultSet rs = null;
        PreparedStatement pstmt = null;

        try {
            conectar();

            pstmt = conexion.prepareStatement("INSERT INTO Ferva.caracteristica (nombre, descripcion,estado) VALUES (?,?,?)");
            //Class.forName("com.mysql.jdbc.Driver");
            // Connection connection = pstmt.getConnection();
            pstmt.setString(1, caracteristicaTO.getNombre());
            pstmt.setString(2, caracteristicaTO.getDescripcion());
            pstmt.setBoolean(3, false);
            pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPreparedStatement(pstmt);
            } catch (SQLException e) {

            }

            desconectar();
        }

    }
    public void actualizar(CaracteristicaTO caracteristicaTO) {
        PreparedStatement pstmt = null;

        try {
            conectar();

            pstmt = conexion.prepareStatement("UPDATE Ferva.caracteristica SET nombre = ? , descripcion = ?, estado = ? WHERE idcaracteristica = '" + caracteristicaTO.getIdcaractaristica()+ "'");
            // Connection connection = pstmt.getConnection();
            pstmt.setString(1, caracteristicaTO.getNombre());
            pstmt.setString(2, caracteristicaTO.getDescripcion());
            pstmt.setBoolean(3, caracteristicaTO.isEstado());

            pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPreparedStatement(pstmt);
            } catch (SQLException e) {

            }

            desconectar();
        }
        System.out.println("Este es la caracteristica a actualizar en la base de datos desde el ServicioCaracteristica: " + caracteristicaTO);
    }
 public void eliminar(CaracteristicaTO caracteristicaTO) {
        PreparedStatement pstmt = null;

        try {
            conectar();

            pstmt = conexion.prepareStatement("DELETE FROM Ferva.caracteristica  WHERE idcaracteristica = '" + caracteristicaTO.getIdcaractaristica()+ "'");

            pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPreparedStatement(pstmt);
            } catch (SQLException e) {

            }

            desconectar();
        }

        System.out.println("Este es la caracteristica a eliminar en la base de datos desde el ServicioCaracteristica: " + caracteristicaTO);
    }
    
}   

