/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;

/**
 *
 * @author User
 */
public class Servicio {
      protected Connection conexion = null;
    private String host = "localhost";
    private String puerto = "3306";
    private String sid = "Ferva";
    private String usuario = "root";
    private String clave = "adminadmin";

    public void conectar() {

        try {
            //Paso 1
            Class.forName("com.mysql.cj.jdbc.Driver");
            //Paso 2
            conexion = DriverManager.getConnection(
                    "jdbc:mysql://" + host + ":" + puerto + "/" + sid + /*"?autoReconnect=true"*/ "?zeroDateTimeBehavior=CONVERT_TO_NULL",
                    usuario, clave);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void cerrarStatement(Statement stmt) {
        try {
            if (stmt != null && !stmt.isClosed()) {
                stmt.close();
                stmt = null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void cerrarResultSet(ResultSet rs) {
        try {
            if (rs != null && !rs.isClosed()) {
                rs.close();
                rs = null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void desconectar() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                conexion = null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
  public void cerrarPreparedStatement(PreparedStatement pstmt) throws SQLException {
      if (pstmt != null && !pstmt.isClosed()) {
          pstmt.close();
          pstmt = null;
      }
    }
}


