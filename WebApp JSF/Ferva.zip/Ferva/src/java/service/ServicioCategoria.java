/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.CategoriaTO;


/**
 *
 * @author Mauricio
 */
public class ServicioCategoria extends Servicio {

    public CategoriaTO existeCategoria(int idCategoria,String nombre, String descripcion, boolean estado) {
        Statement stmt = null;
        ResultSet rs = null;
        CategoriaTO CategoriaTORetorno= null;

        try {
            conectar();

            stmt = conexion.createStatement();
            String sql = "SELECT idCategoria ,nombre, descripcion, estado  FROM categoria WHERE idcategoria = '" + idCategoria + "' AND nombre = '" + nombre + "' AND estado = '" + "1" + "' ";
            rs = stmt.executeQuery(sql);

            if (rs.next()) {
                int idCat = rs.getInt("idCategoria");
                String name = rs.getString("nombre");
                String description = rs.getString("descripcion");
        
                boolean state = rs.getBoolean("estado");

                CategoriaTORetorno = new CategoriaTO(idCat, name, description, state );

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //Paso 5
            cerrarResultSet(rs);
            cerrarStatement(stmt);
            desconectar();
        }
        return CategoriaTORetorno;
    }


    //======================================================================================
    //LISTAR categorias DE LA DB
    //=======================================================================================
    public List<CategoriaTO> listarCategoriasDB() {

        Statement stmt = null;
        ResultSet rs = null;
        List<CategoriaTO> listaRetorno = new ArrayList<>();

        try {
            conectar();
            stmt = conexion.createStatement();
            String sql = "SELECT idCategoria, nombre, descripcion, estado FROM categoria";
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int idCategoria = rs.getInt("idCategoria");
                String nombre = rs.getString("nombre");
                String descripcion = rs.getString("descripcion");
                boolean estado = rs.getBoolean("estado");
                CategoriaTO categoriaTO = new CategoriaTO(idCategoria, nombre, descripcion, estado);
                listaRetorno.add(categoriaTO);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarResultSet(rs);
            cerrarStatement(stmt);
            desconectar();
        }
        return listaRetorno;

    }
    //===============================================================
public void insertar(CategoriaTO categoriaTO) {

        //ResultSet rs = null;
        PreparedStatement pstmt = null;

        try {
            conectar();

            pstmt = conexion.prepareStatement("INSERT INTO Ferva.categoria (nombre, descripcion,estado) VALUES (?,?,?)");
            //Class.forName("com.mysql.jdbc.Driver");
            // Connection connection = pstmt.getConnection();
            pstmt.setString(1, categoriaTO.getNombre());
            pstmt.setString(2, categoriaTO.getDescripcion());
            pstmt.setBoolean(3, false);
            pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPreparedStatement(pstmt);
            } catch (SQLException e) {

            }

            desconectar();
        }

    }
    public void actualizar(CategoriaTO categoriaTO) {
        PreparedStatement pstmt = null;

        try {
            conectar();

            pstmt = conexion.prepareStatement("UPDATE Ferva.categoria SET nombre = ? , descripcion = ?, estado = ? WHERE idCategoria = '" + categoriaTO.getIdcategoria() + "'");
            // Connection connection = pstmt.getConnection();
            pstmt.setString(1, categoriaTO.getNombre());
            pstmt.setString(2, categoriaTO.getDescripcion());
            pstmt.setBoolean(3, categoriaTO.isEstado());

            pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPreparedStatement(pstmt);
            } catch (SQLException e) {

            }

            desconectar();
        }
        System.out.println("Este es la categoria a actualizar en la base de datos desde el ServicioCategoria: " + categoriaTO);
    }
 public void eliminar(CategoriaTO categoriaTO) {
        PreparedStatement pstmt = null;

        try {
            conectar();

            pstmt = conexion.prepareStatement("DELETE FROM Ferva.categoria  WHERE idCategoria = '" + categoriaTO.getIdcategoria()+ "'");

            pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPreparedStatement(pstmt);
            } catch (SQLException e) {

            }

            desconectar();
        }

        System.out.println("Este es la categoria a eliminar en la base de datos desde el ServicioCategoria: " + categoriaTO);
    }
    
}